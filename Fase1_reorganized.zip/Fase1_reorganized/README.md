# EDDMail — Fase 1/2

Estructura reorganizada automáticamente.

## Compilar CLI (pruebas backend)
```bash
fpc -Fu./src/core -Fu./src/adapters/json -Fu./src/adapters/graphviz -FE./bin ./src/cli/main_test.lpr
./bin/main_test
```

## Compilar GUI (Lazarus/LCL, GTK)
```bash
fpc -Fu./src/core -Fu./src/adapters/json -Fu./src/adapters/graphviz -Fu./src/ui -Fu./src/ui/forms -FE./bin ./src/ui/EDDMail.lpr
./bin/EDDMail
```
