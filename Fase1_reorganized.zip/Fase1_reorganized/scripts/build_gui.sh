#!/usr/bin/env bash
set -e
cd "$(dirname "$0")/.."
mkdir -p bin reportes/Root-Reportes reportes/usuarios
fpc -Fu./src/core -Fu./src/adapters/json -Fu./src/adapters/graphviz -Fu./src/ui -Fu./src/ui/forms -FE./bin ./src/ui/EDDMail.lpr
echo "OK -> ./bin/EDDMail"
