#!/usr/bin/env bash
set -e
cd "$(dirname "$0")/.."
mkdir -p bin
fpc -Fu./src/core -Fu./src/adapters/json -Fu./src/adapters/graphviz -FE./bin ./src/cli/main_test.lpr
echo "OK -> ./bin/main_test"
